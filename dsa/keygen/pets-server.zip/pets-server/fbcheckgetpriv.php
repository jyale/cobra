<html>
	<body>
		<div class=crypto-book-keys>
			<span id=keys hidden>
<?php
$token = $_GET["token"];


$data = file_get_contents("https://graph.facebook.com/app/?access_token=" . $token);
$array = json_decode($data, true);

if($array['name']=="Crypto-Bk"){

$pubs[0] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=baford");
$pubs[1] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=christinehong802");
$pubs[2] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=danny.jackowitz");
$pubs[3] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=davidiw");
$pubs[4] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=ennan.zhai");
$pubs[5] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=esyta");
$pubs[6] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=han.ma.39589");
$pubs[7] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=lining.wang");
$pubs[8] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=seth.lifland");
$pubs[9] = file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/getpub.php?id=weiyi.wu.319");

$Data = array('name' => 'Dedis group', 'x' => (file_get_contents("http://mahan.webfactional.com/dsa/keygen/pets-server/fbgetpriv.php?id=" . $token)), 'L' => $pubs);
	echo json_encode($Data);

}else{
	die("Invalid token");
}
?>
			</span>
			<span>Crypto-Book keys for: Dedis group</span></br>
			<button type=button id=save>Save Keys</button>
		</div>
	</body>
</html>
